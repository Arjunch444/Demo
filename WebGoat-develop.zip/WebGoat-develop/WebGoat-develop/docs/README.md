# WebGoat landing page

Old Github page which now redirects to OWASP website.


